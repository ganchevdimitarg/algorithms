import java.util.Iterator;
import java.util.NoSuchElementException;

public class RandomizedQueue<Item> implements Iterable<Item> {
    private Object[] queue;
    private int size;

    // construct an empty randomized queue
    public RandomizedQueue() {
        size = 0;
        queue = new Object[5];
    }

    // is the randomized queue empty?
    public boolean isEmpty() {
        return size == 0;
    }

    // return the number of items on the randomized queue
    public int size() {
        return size;
    }

    // add the item
    public void enqueue(Item item) {
        if (item == null) {
            throw new IllegalArgumentException();
        }
        if (queue.length == size) {
            queue = expand(queue);

        }
        queue[size] = castItem(item);
        size++;

    }

    private Item castItem(Object obj) {
        return (Item) obj;
    }

    private Object[] expand(Object[] q) {
        Object[] newQueue = new Object[q.length * 2];
        System.arraycopy(q, 0, newQueue, 0, q.length);
        return newQueue;
    }

    // remove and return a random item
    public Item dequeue() {
        if (this.isEmpty()) {
            throw new NoSuchElementException();
        }
        int index = getIndex();
        Item element = castItem(queue[index]);
        while (element == null) {
            index = getIndex();
            element = castItem(queue[index]);
        }
        queue[index] = null;
        queue = shrink(queue);
        size--;
        return element;
    }

    private Object[] shrink(Object[] q) {
        Object[] newQueue = new Object[q.length];

        for (int i = 0; i < q.length; i++) {
            if (q[i] != null) {
                newQueue[i] = q[i];
            }
        }
        return newQueue;
    }

    // return a random item (but do not remove it)
    public Item sample() {
        if (this.isEmpty()) {
            throw new NoSuchElementException();
        }
        int index = getIndex();
        Item element = castItem(queue[index]);
        while (element == null) {
            index = getIndex();
            element = castItem(queue[index]);
        }
        return element;
    }

    // return an independent iterator over items in random order
    public Iterator<Item> iterator() {
        return new QueueIterator(this.size);
    }

    private class QueueIterator implements Iterator<Item> {

        private Item current;
        private int counter = 0;
        private final int size;

        public QueueIterator(int size) {
            current = castItem(queue[counter]);
            this.size = size;
        }

        public boolean hasNext() {
            return counter < this.size;
        }

        public Item next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            int index = getIndex();
            Item item = current;
            current = castItem(queue[index]);
            while (current == null) {
                index = getIndex();
                current = castItem(queue[index]);
            }
            counter++;
            return item;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    private int getIndex() {
        return (int) (Math.random() * this.queue.length);
    }

    // unit testing (required)
    public static void main(String[] args) {
        RandomizedQueue<String> test = new RandomizedQueue<>();
        test.enqueue("a");
        test.enqueue("b");
        test.enqueue("c");
        test.enqueue("d");
        test.enqueue("e");
        test.enqueue("f");
        System.out.println(test.dequeue());
        System.out.println(test.sample());
       
        System.out.println(test.iterator().next());
        System.out.println(test.isEmpty());
        System.out.println(test.size());
        System.out.println(test.dequeue());
        System.out.println(test.dequeue());
        System.out.println(test.dequeue());
        System.out.println(test.dequeue());

    }


}