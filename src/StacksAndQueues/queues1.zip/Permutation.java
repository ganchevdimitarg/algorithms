import java.util.Scanner;

public class Permutation {
    public static void main(String[] args) {
        int k = Integer.parseInt(args[0]);

        Scanner scanner = new Scanner(System.in);
        RandomizedQueue<String> test = new RandomizedQueue<>();
        while (scanner.hasNext()) {
            String input = scanner.next();
            test.enqueue(input);
        }
        for (int i = 0; i < k; i++) {
            System.out.println(test.sample());
        }

        scanner.close();
    }
}